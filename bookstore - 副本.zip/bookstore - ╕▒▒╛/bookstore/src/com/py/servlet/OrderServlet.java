package com.py.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.py.factory.DAOFactory;
import com.py.service.CartService;
import com.py.service.OrderService;
import com.py.service.impl.CartServiceImpl;
import com.py.service.impl.OrderServiceImpl;
import com.py.vo.Cart;
import com.py.vo.Member;
import com.py.vo.Order;
import com.py.vo.OrderDetail;
import com.py.vo.SellGoods;

@SuppressWarnings("serial")
public class OrderServlet extends HttpServlet {
	private OrderService orderservice = new OrderServiceImpl();//��ʼ��Service����
	HttpSession session = null;//����HttpSession����
	private String result = null;//����result
	private boolean flag = false;//������ʶ��
	private CartService cartservice = new CartServiceImpl();

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String method = request.getParameter("method");
		if ("insertOrder".equals(method)) {
			session = request.getSession();// �õ�session
			Member member=(Member)session.getAttribute("member");
			@SuppressWarnings("unchecked")//�ύ�������ﳵ
			String account=member.getAccount();
			List<Cart> cart = new ArrayList<Cart>();
			try{
				cart =DAOFactory.getCartDAOInstance().selectCartByAccount(account);//��ȡsession��Χ�ڹ��ﳵcart
			}catch
				(Exception e){
					e.printStackTrace();
				}

//			Cart cart=(Cart)session.getAttribute("cart");
			
//			int goodsId = Integer.parseInt(request.getParameter("goodsId"));
//			float goodsPrice = Float.parseFloat(request.getParameter("price"));
//			int number=1;
			Order order = new Order();//ʵ����order����		
			List<OrderDetail> list = new ArrayList<OrderDetail>();//����List����			
			String orderId = request.getParameter("orderId").trim();//��ȡ������
			order.setOrderId(orderId);
			order.setAccount(request.getParameter("account"));
			order.setReallyName(request.getParameter("reallyName"));
			order.setAddress(request.getParameter("address"));
			order.setTel(request.getParameter("tel"));
			order.setSetMoney(request.getParameter("setMoney"));
			order.setPost(request.getParameter("post"));
			order.setBz(request.getParameter("bz"));
			for (int i = 0; i < cart.size(); i++) {//����ÿһ�����ﳵ����Ʒ��--����һ����ϸ����
				Cart sellgoods = (Cart) cart.get(i);
				OrderDetail orderdetail = new OrderDetail();//ʵ����OrderDetail����
				orderdetail.setOrderId(orderId);
				orderdetail.setGoodsId(sellgoods.getGoodsId());
				orderdetail.setPrice(sellgoods.getGoodsPrice());
				orderdetail.setNumber(sellgoods.getNumber());
				list.add(orderdetail);
			}
			flag = orderservice.insertOrder(order, list);//���ɶ���
			result = orderservice.getResult();
			if(flag){
				//�����ɹ�����������ݿ�
				session.removeAttribute("cart");
				cartservice.deleteCartByAccount(request.getParameter("account"));
				response.sendRedirect("fg-orderDetail.jsp");
			}else{
				//����ʧ�ܣ���ص�ԭ���Ľ���
				request.setAttribute("result", result);
				request.getRequestDispatcher("fg-orderSubmit.jsp")
						.forward(request, response);
			}
		}
		else if("selectOrder".equals(method)){
			List<Order> list = null;
			list = orderservice.selectOrder();
			int pageNumber = list.size();
			int maxPage = pageNumber;
			String number = request.getParameter("i");
			if (maxPage % 10 == 0)
				maxPage = maxPage/10;
			else {
				maxPage = maxPage / 10 + 1;
			}
			if (number == null) {
				number = "0";
			}
			request.setAttribute("number", String.valueOf(number));
			request.setAttribute("maxPage", String.valueOf(maxPage));
			request.setAttribute("pageNumber", String.valueOf(pageNumber));
			request.setAttribute("list", list);
			request.getRequestDispatcher("background/bg-orderSelect.jsp")
			.forward(request, response);
		}
		else if("selectOrderDetailByOrderId".equals(method)){
			String orderId = request.getParameter("orderId");
			List<OrderDetail> list = null;
			list = orderservice.selectOrderDetailByOrderId(orderId);
			int pageNumber = list.size();
			int maxPage = pageNumber;
			String number = request.getParameter("i");
			if (maxPage % 10 == 0)
				maxPage = maxPage/10;
			else {
				maxPage = maxPage / 10 + 1;
			}
			if (number == null) {
				number = "0";
			}
			request.setAttribute("number", String.valueOf(number));
			request.setAttribute("maxPage", String.valueOf(maxPage));
			request.setAttribute("pageNumber", String.valueOf(pageNumber));
			request.setAttribute("list", list);
			request.getRequestDispatcher(
					"background/bg-orderDetailSelect.jsp").forward(request,
					response);
		}
		else if("updateOrderSign".equals(method)){
			String orderId = request.getParameter("orderId");
			flag = orderservice.updateOrderSign(orderId);
			result = orderservice.getResult();
			if(flag){
				response.sendRedirect("OrderServlet.do?method=selectOrder");
			}else{
				request.setAttribute("result", result);
				request.getRequestDispatcher(
						"OrderServlet.do?method=selectOrder").forward(
						request, response);
			}
			
		}
		else if("deleteOrderByOrderId".equals(method)){
			String orderId = request.getParameter("orderId");
			flag = orderservice.deleteOrderByOrderId(orderId);
			result = orderservice.getResult();
			if(flag){
				response.sendRedirect("OrderServlet.do?method=selectOrder");
			}else{
				request.setAttribute("result", result);
				request.getRequestDispatcher(
						"OrderServlet.do?method=selectOrder").forward(
						request, response);
			}
		}
		else if("deletememberOrderByOrderId".equals(method)){
			String orderId = request.getParameter("orderId");
			flag = orderservice.deleteOrderByOrderId(orderId);
			result = orderservice.getResult();
			if(flag){
				response.sendRedirect("fg-orderDetail.jsp");
			}else{
				request.setAttribute("result", result);
				request.getRequestDispatcher("fg-orderDetail.jsp")
				.forward(request, response);
			}
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
}
