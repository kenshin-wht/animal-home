package com.py.servlet;

import java.io.IOException;
import java.util.List;
import java.util.Vector;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.py.factory.DAOFactory;
import com.py.service.MemberService;
import com.py.service.impl.MemberServiceImpl;
import com.py.vo.Cart;
import com.py.vo.Order;
import com.py.vo.SellGoods;
import com.py.vo.Member;
import com.py.service.CartService;
import com.py.service.impl.CartServiceImpl;

@SuppressWarnings("serial")
public class CartServlet extends HttpServlet {
	@SuppressWarnings("unchecked")
	private CartService cartservice = new CartServiceImpl();
	private boolean flag = false;//������ʶ��
	private String result = null;//����result
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{
		String method = request.getParameter("method");
		HttpSession session = request.getSession();
		Member member=(Member)session.getAttribute("member");
		if("cartAdd".equals(method)){
			
		if(member==null){
				response.sendRedirect("fg-memberLogin.jsp");
			}
			else{
				int goodsId = Integer.parseInt(request.getParameter("goodsId"));
				float goodsPrice = Float.parseFloat(request.getParameter("price"));
			try {
						List<Cart> cartList=DAOFactory.getCartDAOInstance().selectCartByAccount(member.getAccount());
						boolean exist=false;
						int i=0;
					for(i=0;i<cartList.size();i++)
					{
						if(goodsId==cartList.get(i).getGoodsId())
						{
							exist=true;
							Cart newcart=cartList.get(i);
							break;
						}
					}
					if(exist==false)
					{
						Cart cart1=new Cart();
						int number=1;
						cart1.setAccount(member.getAccount());
						System.out.println(member.getAccount());
						cart1.setGoodsId(goodsId);
						cart1.setGoodsPrice(goodsPrice);
						cart1.setNumber(number);
						flag = cartservice.insertCart(cart1);
						result = cartservice.getResult();		
						if(flag)
						{
						session.setAttribute("cart",cart1);
						response.sendRedirect("fg-cartSee.jsp");
						}
					}
					else
					{
	//					Cart cart1=new Cart();
	//					int number=1;
	//					cart1.setAccount(member.getAccount());
	//					System.out.println(member.getAccount());
	//					cart1.setGoodsId(goodsId);
	//					cart1.setGoodsPrice(goodsPrice);
	//					cart1.setNumber(number);
						flag=cartservice.updateNumber(cartList.get(i));
						if(flag)
						{
						//session.setAttribute("cart",cart1);
						response.sendRedirect("fg-cartSee.jsp");
						}
				}
			}catch (Exception e) {
				// TODO Auto-generated catch block//
				e.printStackTrace();
			}
		
			// �õ�session
			
			}
		}
//			else if("selectOrder".equals(method)){
//				List<Cart> cart = null;
//				cart= cartservice.selectCart();
//				int pageNumber = cart.size();
//				int maxPage = pageNumber;
//				String number1 = request.getParameter("CartNumber");
//				if (maxPage % 10 == 0)
//					maxPage = maxPage/10;
//				else {
//					maxPage = maxPage / 10 + 1;
//				}
//				if (number1 == null) {
//					number1 = "0";
//				}
//				request.setAttribute("number", String.valueOf(number1));
//				//request.setAttribute("maxPage", String.valueOf(maxPage));
//				//request.setAttribute("pageNumber", String.valueOf(pageNumber));
//				request.setAttribute("list", cart);
//				request.getRequestDispatcher("fg-cartSee.jsp")
//				.forward(request, response);
//			}
		else if("deleteCartByGoodsId".equals(method)){
			
			String account = member.getAccount();
			String goodsId = request.getParameter("goodsId");
			System.out.println(account);
			System.out.println(goodsId);
			flag = cartservice.deleteCartByGoodsId(account,goodsId);
			result = cartservice.getResult();
			if(flag)
			{
				response.sendRedirect("fg-cartSee.jsp");
			}else{
				request.setAttribute("result", result);
				request.getRequestDispatcher("fg-cartSee.jsp")
						.forward(request, response);
			}
			

		}
		
			else if("deleteCartByAccount".equals(method)){
//				HttpSession session1 = request.getSession();
//				Member member1=(Member)session.getAttribute("member");
				//String account = member.getAccount();
				
				String account = request.getParameter("account");
				
				flag = cartservice.deleteCartByAccount(account);
				result = cartservice.getResult();
				if(flag)
				{
					//session.removeAttribute("cart");
//					response.sendRedirect("CartServlet.do?method=selectCart");
				response.sendRedirect("fg-cartSee.jsp");
				}else{
					request.setAttribute("result", result);
					request.getRequestDispatcher("fg-cartSee.jsp")
							.forward(request, response);
				}

			}
		if("cartModify".equals(method)){
			String vnum = request.getParameter("num1");
			int cartsize=Integer.parseInt(request.getParameter("cartsize")) ;
			//System.out.println(vnum);
			String vgooodsId = request.getParameter("goodsPrice1");
			String account =request.getParameter("account");
			//System.out.println(vgooodsId);
			for(int i=0;i<cartsize;i++){
				//SellGoods mygoodselement=(SellGoods)cart.elementAt(i);//��ȡÿ����Ʒ�Ķ���
				Cart ncart=new Cart();
				ncart.setAccount(account);
				ncart.setGoodsId(Integer.parseInt(request.getParameter("goodsId"+i)));
				ncart.setGoodsPrice(Float.parseFloat(request.getParameter("goodsPrice"+i)));
				ncart.setNumber(Integer.parseInt(request.getParameter("num"+i))-1);
				cartservice.updateNumber(ncart);
			}
			//session.setAttribute("cart",newcart);//��newcart���󱣴���session��
			response.sendRedirect("fg-cartSee.jsp");//�ͻ�����ת��fg-cartSee.jsp
			
		}



		


	}
	public void doGet(HttpServletRequest request,HttpServletResponse response)
			throws ServletException,IOException{
			this.doPost(request,response);
	}
}