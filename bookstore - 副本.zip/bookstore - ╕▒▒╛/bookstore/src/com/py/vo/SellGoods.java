package com.py.vo;

public class SellGoods {
	public int Id;
	public float price;
	public int number;
}
