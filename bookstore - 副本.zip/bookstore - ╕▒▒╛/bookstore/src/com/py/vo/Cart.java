package com.py.vo;

public class Cart {
	private String account;//��Ա�˺�
	private int goodsId;//��ƷID
	private float goodsPrice;//��Ʒ�۸�
	private int number;//����
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public int getGoodsId() {
		return goodsId;
	}
	public void setGoodsId(int password) {
		this.goodsId = password;
	}
	public float getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(float goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
}
