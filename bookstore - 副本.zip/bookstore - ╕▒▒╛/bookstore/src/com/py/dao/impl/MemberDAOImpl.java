package com.py.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.py.dao.MemberDAO;
import com.py.vo.Member;

public class MemberDAOImpl implements MemberDAO {
	private Connection conn = null;
	private PreparedStatement ps = null;

	public MemberDAOImpl(Connection conn) {
		this.conn = conn;
	}

	@Override
	/*
	 * ͨ����Ա�˺Ų�ѯ�û�
	 */
	public Member selectMemberByAccount(String account) throws Exception {
	
		Member member = null;
		String sql = "SELECT * FROM tb_member WHERE account=?";
		this.ps = this.conn.prepareStatement(sql);
		this.ps.setString(1, account);
		ResultSet rs = this.ps.executeQuery();
		if(rs.next()){
			member = new Member();
			member.setAccount(rs.getString(1));
			member.setPassword(rs.getString(2));
			member.setReallyName(rs.getString(3));
			member.setEmail(rs.getString(4));
			member.setTel(rs.getString(5));
			member.setIdCard(rs.getString(6));
		}
		this.ps.close();
		return member;
	}


	@Override
	/*
	 * ��ѯ���л�Ա
	 */
	public List<Member> selectMember() throws Exception {
		List<Member> list = new ArrayList<Member>();
		String sql = "SELECT * FROM tb_member";
		this.ps = this.conn.prepareStatement(sql);
		ResultSet rs = this.ps.executeQuery();
		Member member = null;
		while(rs.next()){
			member = new Member();
			member.setAccount(rs.getString(1));
			member.setPassword(rs.getString(2));
			member.setReallyName(rs.getString(3));
			member.setEmail(rs.getString(4));
			member.setTel(rs.getString(5));
			member.setIdCard(rs.getString(6));
			list.add(member);
		}
		this.ps.close();
		return list;
    }


	@Override
	/*
	 * ���ӻ�Ա
	 */
	public boolean insertMember(Member member) throws Exception {
		boolean flag = false;
		String sql = "INSERT INTO tb_member VALUES(?,?,?,?,?,?)";
		this.ps = this.conn.prepareStatement(sql);			
		this.ps.setString(1,member.getAccount());
		this.ps.setString(2,member.getPassword());
		this.ps.setString(3,member.getReallyName());
		this.ps.setString(4,member.getEmail());
		this.ps.setString(5,member.getTel());
		this.ps.setString(6,member.getIdCard());
		if(this.ps.executeUpdate()>0){
			flag = true;
		}
		this.ps.close();
		return flag;
	}


	@Override
	/*
	 * ɾ����Ա
	 */
	public boolean deleteMemberByAccount(String account) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		String sql = "DELETE FROM tb_member WHERE account=?";
		this.ps = this.conn.prepareStatement(sql);
		this.ps.setString(1, account);
		if(this.ps.executeUpdate()>0){
			flag = true;
		}
		this.ps.close();
		return flag;
	}

	@Override
	/*
	 * �޸Ļ�Ա��Ϣ
	 */
	public boolean updateMember(Member member) throws Exception {
		boolean flag = false;
		String sql = "UPDATE tb_member SET password=?,reallyName=?,email=?,tel=? ,idCard=? WHERE account=?";
		this.ps = this.conn.prepareStatement(sql);	
		this.ps.setString(1,member.getPassword());
		this.ps.setString(2,member.getReallyName());
		this.ps.setString(3,member.getEmail());
		this.ps.setString(4,member.getTel());
		this.ps.setString(5,member.getIdCard());
		this.ps.setString(6,member.getAccount());
		if(this.ps.executeUpdate()>0){
			flag = true;
		}
		this.ps.close();
		return flag;
	}


}
