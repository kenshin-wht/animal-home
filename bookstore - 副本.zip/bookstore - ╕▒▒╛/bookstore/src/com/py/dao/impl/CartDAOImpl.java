package com.py.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.py.dao.CartDAO;
import com.py.vo.Cart;
import com.py.vo.Order;
import com.py.vo.OrderDetail;

public class CartDAOImpl implements CartDAO{
	private Connection conn = null;// �������ݿ����Ӷ���
	private PreparedStatement ps = null;// �������ݿ��������

	public CartDAOImpl(Connection conn) {// �������ݿ�����
		this.conn = conn;
	}
	/*
	 * ���Ӷ���
	 */
	public boolean insertCart(Cart order) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		String sql = "INSERT INTO tb_cart VALUES(?,?,?,?)";
		this.ps = this.conn.prepareStatement(sql);
		this.ps.setString(1,order.getAccount());
		this.ps.setString(2,Integer.toString(order.getGoodsId()));
		this.ps.setString(3,Double.toString(order.getGoodsPrice()));
		this.ps.setString(4,Integer.toString(order.getNumber()));
		if(this.ps.executeUpdate()>0){
			flag = true;
		}
		this.ps.close();
		return flag;
	}
	
	
	public List<Cart> selectCartByAccount(String account) throws Exception {
		// TODO Auto-generated method stub
		List<Cart> list = new ArrayList<Cart>();
		String sql = "SELECT * FROM tb_cart WHERE account=? ";//���ܳ���
		this.ps = this.conn.prepareStatement(sql);
		this.ps.setString(1,account);
		ResultSet rs = this.ps.executeQuery();
		Cart order = null;
		while(rs.next()){
			order = new Cart();
			order.setAccount(rs.getString(1));
			order.setGoodsId( Integer.parseInt(rs.getString(2)));
			order.setGoodsPrice(Float.parseFloat(rs.getString(3)));
			order.setNumber(Integer.parseInt(rs.getString(4)));
			list.add(order);
		}
		this.ps.close();
		return list;
	}
	//����ɾ���������
	public boolean deleteCartByAccount(String account) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		String sql = "DELETE FROM tb_cart WHERE account=?";
		this.ps = this.conn.prepareStatement(sql);
		this.ps.setString(1, account);
		if(this.ps.executeUpdate()>0){
			flag = true;
		}
		this.ps.close();
		return flag;
	}
	@Override
	public boolean deleteCartByGoodsId(String account, String goodsId)
			throws Exception {
		boolean flag = false;
		String sql = "DELETE FROM tb_cart WHERE account=? AND goodsId=?";
		this.ps = this.conn.prepareStatement(sql);
		this.ps.setString(1, account);
		this.ps.setString(2, goodsId);
		if(this.ps.executeUpdate()>0){
			flag = true;
		}
		this.ps.close();
		return flag;
	}
	@Override
	public boolean updateNumber(Cart cart) throws Exception {
		boolean flag = false;
		String sql = "UPDATE tb_cart SET goodsPrice=?,number=? WHERE account=?AND goodsId=?";
		this.ps = this.conn.prepareStatement(sql);	
		this.ps.setString(1,Float.toString(cart.getGoodsPrice()));
		this.ps.setString(2,Integer.toString(cart.getNumber()+1));//
		this.ps.setString(3,cart.getAccount());
		this.ps.setString(4,Integer.toString(cart.getGoodsId()));
//		this.ps.setString(5,member.getIdCard());
//		this.ps.setString(6,member.getAccount());
		if(this.ps.executeUpdate()>0){
			flag = true;
		}
		this.ps.close();
		return flag;
	}
	

}