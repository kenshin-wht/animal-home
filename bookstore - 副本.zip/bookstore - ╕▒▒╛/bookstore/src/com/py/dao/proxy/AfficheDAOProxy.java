package com.py.dao.proxy;

import java.util.List;
import com.py.dao.AfficheDAO;
import com.py.dao.impl.AfficheDAOImpl;
import com.py.tool.DatabaseConnection;
import com.py.vo.Affiche;

public class AfficheDAOProxy implements AfficheDAO{
	private DatabaseConnection dbc = null;
	private AfficheDAO dao = null;
	public AfficheDAOProxy()throws Exception{
		this.dbc = new DatabaseConnection();
		this.dao = new AfficheDAOImpl(this.dbc.getConnection());
	}
	@Override
	/*
	 * ��ѯ��վ����
	 */
	public List<Affiche> selectAffiche() throws Exception {
		// TODO Auto-generated method stub
		List<Affiche> list = null;
		try{
			list = this.dao.selectAffiche();
		}catch(Exception e){
			throw e;
		}finally{
			this.dbc.close();
		}
		return list;
	}

	@Override
	/*
	 * ����վ�����Ų�ѯ��վ����
	 */
	public Affiche selectAfficheById(int id) throws Exception {
		// TODO Auto-generated method stub
		Affiche affiche = null;
		try{
			affiche = this.dao.selectAfficheById(id);
		}catch(Exception e){
			throw e;
		}finally{
			this.dbc.close();
		}
		return affiche;
	}

	@Override
	/*
	 * ������վ����
	 */
	public boolean insertAffiche(Affiche affiche) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;
		try{
			flag = this.dao.insertAffiche(affiche);
		}catch(Exception e){
			throw e;
		}finally{
			this.dbc.close();
		}
		return flag;
	}

	@Override
	/*
	 * ɾ����վ����
	 */
	public boolean deleteAfficheById(int id) throws Exception {
		// TODO Auto-generated method stub
		boolean flag = false;//�����־λ
		try{
			if(this.dao.selectAfficheById(id)!=null){
				flag = this.dao.deleteAfficheById(id);
			}
		}catch(Exception e){
			throw e;
		}finally{
			this.dbc.close();
		}
		return flag;
	}

}
