package com.py.dao;
import java.util.List;
import com.py.vo.Cart;
import com.py.vo.Order;

public interface CartDAO {
	
	/*
	 * ���Ӷ���
	 */
	public boolean insertCart(Cart order)throws Exception;
	
	public List<Cart> selectCartByAccount(String account)throws Exception;
//ɾ������
	public boolean deleteCartByAccount(String account)throws Exception;
	
	public boolean updateNumber(Cart cart)throws Exception;
	
	public boolean deleteCartByGoodsId(String account, String goodsId)throws Exception;
}