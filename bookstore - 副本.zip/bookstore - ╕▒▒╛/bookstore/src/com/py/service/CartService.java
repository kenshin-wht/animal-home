package com.py.service;

import java.util.List;

import com.py.vo.Cart;
import com.py.vo.Member;
import com.py.vo.Order;

public interface  CartService {
	public String getResult();
	public void setResult(String result);
	
	public boolean insertCart(Cart cart);
	
//	public List<Cart> selectCart();
	
	//���ӵ�ɾ������
	public boolean deleteCartByAccount(String Account);
	public boolean updateNumber(Cart cart);
	public boolean deleteCartByGoodsId(String account, String goodsId);
}
